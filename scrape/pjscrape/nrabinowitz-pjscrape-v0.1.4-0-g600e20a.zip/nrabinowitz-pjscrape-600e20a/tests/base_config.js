// configuration for all tests

pjs.config({
    timeoutInterval: 10,
    log: 'none'
});