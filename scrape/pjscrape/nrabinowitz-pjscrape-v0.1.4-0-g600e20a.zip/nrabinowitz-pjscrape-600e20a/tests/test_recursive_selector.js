
pjs.addSuite({
    url: 'http://localhost:8888/test_site/index.html',
    moreUrls: 'li a',
    scraper: 'h1'
});